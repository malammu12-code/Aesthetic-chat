import React from 'react';
import { Link } from 'react-router-dom';
import { Music, Link2, Play, ShieldCheck, ArrowRight } from 'lucide-react';

const steps = [
  {
    icon: Link2,
    title: '1. CONNECT SPOTIFY',
    body: 'Click "Connect Spotify" inside the app. You\'ll be sent to Spotify\'s official login page — sign in with your own Spotify account (Free or Premium).',
  },
  {
    icon: ShieldCheck,
    title: '2. APPROVE ACCESS',
    body: 'Spotify asks you to approve the app. We only read your library and control playback — nothing is stored or shared. Approve and you\'re sent right back.',
  },
  {
    icon: Play,
    title: '3. START LISTENING',
    body: 'Search any track, build a queue, make playlists, and play. Premium accounts stream full songs; Free accounts get 30-second previews.',
  },
];

export default function Intro() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-2xl space-y-6">
        {/* Header */}
        <div className="flex flex-col items-center text-center">
          <div className="w-14 h-14 bg-[#a7e9c5] border-[3px] border-[#3d7a5e] flex items-center justify-center pixel-font text-[#3d7a5e] text-2xl shadow-[4px_4px_0_0_#3d7a5e]">
            ♪
          </div>
          <h1 className="pixel-font text-sm sm:text-lg text-mint-accent mt-4" style={{ textShadow: '0 0 10px rgba(95,184,138,0.4)' }}>
            PIXEL PLAYER
          </h1>
          <p className="pixel-body text-xl text-lav-muted mt-2 leading-snug max-w-md">
            An 8-bit music player that syncs with your Spotify. Here's how to get started.
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-4">
          {steps.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.title} className="pixel-panel p-4 sm:p-5 flex gap-4 items-start">
                <div className="pixel-icon-btn h-12 w-12 shrink-0">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="pixel-font text-[10px] sm:text-xs text-cyan-accent mb-2">{s.title}</h3>
                  <p className="pixel-body text-lg sm:text-xl text-lav-text leading-snug">{s.body}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Note */}
        <div className="pixel-inset p-4 text-center">
          <p className="pixel-body text-base text-lav-muted leading-snug">
            Everyone uses their own Spotify account — there's no shared login. Each listener connects once and they're set.
          </p>
        </div>

        {/* CTA */}
        <div className="flex justify-center">
          <Link to="/app" className="pixel-btn pixel-btn-accent px-6 py-4 text-[10px] sm:text-xs flex items-center gap-3">
            ENTER THE APP
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}