import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { handleSpotifyRedirect } from '@/lib/spotifyAuth';

export default function SpotifyCallback() {
  const navigate = useNavigate();
  const [msg, setMsg] = useState('Linking Spotify...');

  useEffect(() => {
    let done = false;
    handleSpotifyRedirect().then((res) => {
      if (done) return;
      done = true;
      setMsg(res?.error ? `Spotify link failed: ${res.error}` : 'Spotify connected! Redirecting...');
      setTimeout(() => navigate('/', { replace: true }), 700);
    });
    return () => { done = true; };
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fff5fb]">
      <div className="pixel-panel p-6 flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-4 border-[#a7e9c5] border-t-[#3d7a5e] rounded-full animate-spin" />
        <p className="pixel-font text-[10px] text-mint-accent text-center leading-relaxed">{msg}</p>
      </div>
    </div>
  );
}