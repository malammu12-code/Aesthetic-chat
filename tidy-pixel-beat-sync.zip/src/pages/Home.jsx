import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { usePlayer } from '@/lib/usePlayer';
import { useSpotifyPlayer } from '@/lib/useSpotifyPlayer';
import { isSpotifyConnected, handleSpotifyRedirect } from '@/lib/spotifyAuth';
import NowPlaying from '@/components/player/NowPlaying';
import PlayerControls from '@/components/player/PlayerControls';
import TrackList from '@/components/player/TrackList';
import SpotifyConnect from '@/components/player/SpotifyConnect';
import SpotifySearch from '@/components/player/SpotifySearch';
import PlaylistPanel from '@/components/player/PlaylistPanel';
import AddTrackForm from '@/components/player/AddTrackForm';
import RhythmGame from '@/components/player/RhythmGame';
import HistoryPanel from '@/components/player/HistoryPanel';

export default function Home() {
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeSource, setActiveSource] = useState('local');
  const [spotifyConnected, setSpotifyConnected] = useState(isSpotifyConnected());
  const [history, setHistory] = useState([]);
  const [user, setUser] = useState(null);
  const [highScore, setHighScore] = useState(0);
  const lastLoggedRef = useRef(null);
  const queueRecordRef = useRef(null);
  const loadedQueueRef = useRef(false);
  const saveTimerRef = useRef(null);
  const audioPlayer = usePlayer(tracks);
  const spotifyPlayer = useSpotifyPlayer(spotifyConnected);

  useEffect(() => {
    handleSpotifyRedirect().then((res) => {
      if (res?.connected) setSpotifyConnected(true);
    });
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const u = await base44.auth.me();
        if (!active || !u) return;
        setUser(u);
        // Restore this user's saved queue
        try {
          const queues = await base44.entities.UserQueue.filter({ created_by_id: u.id }, '-created_date', 1);
          if (queues.length && queues[0].tracks?.length) {
            queueRecordRef.current = queues[0].id;
            setTracks(queues[0].tracks);
            if (typeof queues[0].current_index === 'number') audioPlayer.setIndex(queues[0].current_index);
          } else {
            const lib = await base44.entities.Track.list('-created_date', 50);
            if (active) setTracks(lib);
          }
        } catch (_) {}
        // Restore listening history
        base44.entities.ListeningHistory.filter({ created_by_id: u.id }, '-created_date', 20)
          .then(setHistory).catch(() => {});
        // Restore best game score
        try {
          const scores = await base44.entities.GameScore.filter({ created_by_id: u.id }, '-score', 1);
          if (active && scores.length) setHighScore(scores[0].score || 0);
        } catch (_) {}
      } catch (_) {}
      finally {
        if (active) { loadedQueueRef.current = true; setLoading(false); }
      }
    })();
    return () => { active = false; };
  }, []);

  const player = activeSource === 'spotify' ? spotifyPlayer : audioPlayer;

  const logHistory = (t) => {
    if (!t || !user) return;
    const key = t.spotify_uri || t.audio_url || `${t.title}|${t.artist}`;
    if (lastLoggedRef.current === key) return;
    lastLoggedRef.current = key;
    base44.entities.ListeningHistory.create({
      title: t.title,
      artist: t.artist,
      cover_url: t.cover_url || '',
      audio_url: t.audio_url || '',
      spotify_uri: t.spotify_uri || '',
      source: t.source || 'local',
    }).then(() => {
      if (!user) return;
      base44.entities.ListeningHistory.filter({ created_by_id: user.id }, '-created_date', 20)
        .then(setHistory).catch(() => {});
    }).catch(() => {});
  };

  const playLocal = (i) => {
    const track = tracks[i];
    logHistory(track);
    if (track?.spotify_uri && spotifyConnected && spotifyPlayer.ready) {
      audioPlayer.pause?.();
      setActiveSource('spotify');
      const uris = tracks.filter((x) => x.spotify_uri).map((x) => x.spotify_uri);
      const offset = uris.indexOf(track.spotify_uri);
      spotifyPlayer.playUris(uris, offset < 0 ? 0 : offset);
    } else {
      if (activeSource === 'spotify') spotifyPlayer.pause();
      setActiveSource('local');
      audioPlayer.playTrack(i);
    }
  };

  const playSpotifyResult = (t) => {
    const mapped = {
      title: t.title,
      artist: t.artist,
      album: t.album || '',
      cover_url: t.cover_url || '',
      audio_url: t.preview_url,
      spotify_uri: t.spotify_uri,
      duration: t.duration_ms ? Math.round(t.duration_ms / 1000) : 0,
      source: 'spotify',
    };
    const newTracks = [mapped, ...tracks];
    setTracks(newTracks);
    logHistory(mapped);
    if (spotifyConnected && spotifyPlayer.ready && mapped.spotify_uri) {
      audioPlayer.pause?.();
      setActiveSource('spotify');
      const uris = newTracks.filter((x) => x.spotify_uri).map((x) => x.spotify_uri);
      const offset = uris.indexOf(mapped.spotify_uri);
      spotifyPlayer.playUris(uris, offset < 0 ? 0 : offset);
    } else {
      setActiveSource('local');
      audioPlayer.playTrack(0);
    }
  };

  const playPlaylist = (plTracks) => {
    setTracks(plTracks);
    logHistory(plTracks[0]);
    if (plTracks[0]?.spotify_uri && spotifyConnected && spotifyPlayer.ready) {
      setActiveSource('spotify');
      const uris = plTracks.filter((x) => x.spotify_uri).map((x) => x.spotify_uri);
      spotifyPlayer.playUris(uris, 0);
    } else {
      setActiveSource('local');
      audioPlayer.playTrack(0);
    }
  };

  const reorderQueue = (from, to) => {
    if (to < 0 || to > tracks.length - 1) return;
    setTracks((prev) => {
      const next = [...prev];
      const [m] = next.splice(from, 1);
      next.splice(to, 0, m);
      return next;
    });
    if (activeSource === 'local') {
      const cur = audioPlayer.currentIndex;
      let ni = cur;
      if (from === cur) ni = to;
      else if (from < cur && to >= cur) ni = cur - 1;
      else if (from > cur && to <= cur) ni = cur + 1;
      audioPlayer.setIndex(ni);
    }
  };

  const deleteTrack = (i) => {
    setTracks((prev) => prev.filter((_, idx) => idx !== i));
    if (activeSource === 'local') {
      const cur = audioPlayer.currentIndex;
      let ni = cur;
      if (i < cur) ni = cur - 1;
      const newLen = tracks.length - 1;
      if (ni >= newLen) ni = Math.max(0, newLen - 1);
      audioPlayer.setIndex(ni);
    }
  };

  const spotifyCurrentIndex =
    activeSource === 'spotify' && spotifyPlayer.currentTrack?.spotify_uri
      ? tracks.findIndex((t) => t.spotify_uri === spotifyPlayer.currentTrack.spotify_uri)
      : -1;

  // Catches auto-advance (Spotify playing through the queue) — explicit plays log directly via logHistory()
  useEffect(() => {
    logHistory(player.currentTrack);
  }, [player.currentTrack, user]);

  const playHistoryTrack = (t) => {
    setTracks((prev) => [t, ...prev]);
    logHistory(t);
    if (t.spotify_uri && spotifyConnected && spotifyPlayer.ready) {
      audioPlayer.pause?.();
      setActiveSource('spotify');
      spotifyPlayer.playUris([t.spotify_uri], 0);
    } else {
      setActiveSource('local');
      audioPlayer.playTrack(0);
    }
  };

  // Persist the queue (tracks + position) so it survives reloads / revisits
  useEffect(() => {
    if (!loadedQueueRef.current || !user) return;
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(async () => {
      try {
        const payload = { tracks, current_index: activeSource === 'local' ? audioPlayer.currentIndex : 0 };
        if (queueRecordRef.current) {
          await base44.entities.UserQueue.update(queueRecordRef.current, payload);
        } else {
          const rec = await base44.entities.UserQueue.create(payload);
          queueRecordRef.current = rec.id;
        }
      } catch (_) {}
    }, 800);
    return () => { if (saveTimerRef.current) clearTimeout(saveTimerRef.current); };
  }, [tracks, audioPlayer.currentIndex, activeSource, user]);

  const handleGameOver = async (score) => {
    if (!user || score == null) return;
    try {
      await base44.entities.GameScore.create({ score, track_title: player.currentTrack?.title || '' });
      if (score > highScore) setHighScore(score);
    } catch (_) {}
  };

  return (
    <div className="min-h-screen pb-40">
      <header className="px-4 sm:px-6 py-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-[#a7e9c5] border-[3px] border-[#3d7a5e] flex items-center justify-center pixel-font text-[#3d7a5e] text-lg shadow-[4px_4px_0_0_#3d7a5e]">
            ♪
          </div>
          <div>
            <h1 className="pixel-font text-xs sm:text-base text-mint-accent" style={{ textShadow: '0 0 10px rgba(95,184,138,0.4)' }}>
              PIXEL PLAYER
            </h1>
            <p className="pixel-body text-base text-lav-muted leading-none mt-1">8-bit sound system</p>
          </div>
        </div>
        <SpotifyConnect connected={spotifyConnected} />
      </header>

      <div className="px-4 sm:px-6 max-w-5xl mx-auto mb-4 space-y-4">
        <SpotifySearch
          onPlayTrack={playSpotifyResult}
          spotifyConnected={spotifyConnected}
          playerReady={spotifyPlayer.ready}
        />
        <AddTrackForm
          onAdded={(t) => setTracks((prev) => (Array.isArray(t) ? [...t, ...prev] : [t, ...prev]))}
          onPlay={() => setTimeout(() => playLocal(0), 0)}
        />
        {spotifyPlayer.error && (
          <p className="pixel-body text-sm text-pink-accent mt-2 text-right">{spotifyPlayer.error}</p>
        )}
      </div>

      <section className="px-4 sm:px-6 max-w-5xl mx-auto mb-4">
        <RhythmGame audioEl={audioPlayer.audioEl} isPlaying={player.isPlaying} onGameOver={handleGameOver} highScore={highScore} />
      </section>

      <section className="px-4 sm:px-6 max-w-5xl mx-auto mb-4">
        <HistoryPanel history={history} onPlay={playHistoryTrack} />
      </section>

      <main className="px-4 sm:px-6 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <NowPlaying track={player.currentTrack} isPlaying={player.isPlaying} />
        </div>
        <div className="min-h-[320px] md:max-h-[520px]">
          {loading ? (
            <div className="pixel-panel p-6 h-full flex items-center justify-center pixel-body text-2xl text-lav-muted">
              LOADING...
            </div>
          ) : tracks.length === 0 ? (
            <div className="pixel-panel p-6 h-full flex items-center justify-center pixel-body text-2xl text-lav-muted">
              NO TRACKS FOUND
            </div>
          ) : (
            <TrackList
              tracks={tracks}
              currentIndex={activeSource === 'local' ? audioPlayer.currentIndex : spotifyCurrentIndex}
              onSelect={playLocal}
              isPlaying={player.isPlaying}
              onReorder={reorderQueue}
              onDelete={deleteTrack}
            />
          )}
        </div>
      </main>

      <section className="px-4 sm:px-6 max-w-5xl mx-auto mt-4 mb-4">
        <PlaylistPanel
          currentTrack={player.currentTrack}
          onPlayPlaylist={playPlaylist}
          spotifyPlayer={spotifyPlayer}
        />
      </section>

      <div className="fixed bottom-0 left-0 right-0 px-4 sm:px-6 pb-4 pt-2 bg-gradient-to-t from-[#fff5fb] to-transparent">
        <div className="max-w-5xl mx-auto">
          <PlayerControls player={player} />
        </div>
      </div>
    </div>
  );
}