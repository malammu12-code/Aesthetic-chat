import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, ListMusic, X, Play, Trash2, ChevronUp, ChevronDown } from 'lucide-react';

export default function PlaylistPanel({ currentTrack, onPlayPlaylist, spotifyPlayer }) {
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [openId, setOpenId] = useState(null);

  const load = () => {
    setLoading(true);
    base44.entities.Playlist.list('-created_date', 50)
      .then((data) => setPlaylists(data))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const create = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    await base44.entities.Playlist.create({ name: name.trim(), description: description.trim(), tracks: [] });
    setName(''); setDescription(''); setShowForm(false);
    load();
  };

  const addCurrent = async (pl) => {
    if (!currentTrack) return;
    const exists = (pl.tracks || []).some((t) =>
      (t.spotify_uri && t.spotify_uri === currentTrack.spotify_uri) ||
      (t.audio_url && t.audio_url === currentTrack.audio_url)
    );
    const tracks = exists ? pl.tracks : [...(pl.tracks || []), {
      title: currentTrack.title,
      artist: currentTrack.artist,
      album: currentTrack.album || '',
      cover_url: currentTrack.cover_url || '',
      audio_url: currentTrack.audio_url || '',
      spotify_uri: currentTrack.spotify_uri || '',
      duration: currentTrack.duration || 0,
      source: currentTrack.source || 'local',
    }];
    await base44.entities.Playlist.update(pl.id, { tracks });
    load();
  };

  const removeTrack = async (pl, idx) => {
    const tracks = (pl.tracks || []).filter((_, i) => i !== idx);
    await base44.entities.Playlist.update(pl.id, { tracks });
    load();
  };

  const reorderTrack = async (pl, from, to) => {
    const list = [...(pl.tracks || [])];
    if (to < 0 || to >= list.length) return;
    const [m] = list.splice(from, 1);
    list.splice(to, 0, m);
    await base44.entities.Playlist.update(pl.id, { tracks: list });
    load();
  };

  const removePlaylist = async (pl) => {
    await base44.entities.Playlist.delete(pl.id);
    if (openId === pl.id) setOpenId(null);
    load();
  };

  const playPlaylist = async (pl) => {
    if (!pl.tracks || pl.tracks.length === 0) return;
    const first = pl.tracks[0];
    if (first.spotify_uri && spotifyPlayer?.ready) {
      onPlayPlaylist(pl.tracks);
    } else {
      onPlayPlaylist(pl.tracks);
    }
  };

  return (
    <div className="pixel-panel p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="pixel-font text-[10px] sm:text-xs text-pink-accent flex items-center gap-2">
          <ListMusic className="w-4 h-4" /> PLAYLISTS
        </h3>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="pixel-btn pixel-btn-mint px-2 py-1 text-[8px] flex items-center gap-1"
        >
          <Plus className="w-3 h-3" /> NEW
        </button>
      </div>

      {showForm && (
        <form onSubmit={create} className="pixel-inset p-3 mb-3 space-y-2">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="PLAYLIST NAME..."
            className="w-full bg-transparent outline-none pixel-body text-lg text-lav-text placeholder:text-lav-muted py-1"
          />
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Description (optional)"
            className="w-full bg-transparent outline-none pixel-body text-base text-lav-text placeholder:text-lav-muted py-1"
          />
          <div className="flex gap-2">
            <button type="submit" className="pixel-btn pixel-btn-mint px-3 py-2 text-[8px] flex-1">CREATE</button>
            <button type="button" onClick={() => setShowForm(false)} className="pixel-icon-btn h-9 w-9">
              <X className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="pixel-body text-lg text-lav-muted text-center py-4">LOADING...</p>
      ) : playlists.length === 0 ? (
        <p className="pixel-body text-base text-lav-muted text-center py-4">No playlists yet. Create one!</p>
      ) : (
        <div className="space-y-2 max-h-80 overflow-y-auto pixel-scroll pr-1">
          {playlists.map((pl) => (
            <div key={pl.id} className="pixel-inset">
              <div className="flex items-center gap-2 p-2">
                <button
                  onClick={() => addCurrent(pl)}
                  disabled={!currentTrack}
                  className="pixel-icon-btn h-9 w-9 shrink-0 pixel-btn-pink"
                  title="Add current track"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setOpenId(openId === pl.id ? null : pl.id)}
                  className="flex-1 text-left min-w-0"
                >
                  <p className="pixel-body text-lg text-lav-text truncate leading-tight">{pl.name}</p>
                  <p className="pixel-body text-xs text-lav-muted truncate leading-tight">
                    {(pl.tracks || []).length} tracks
                  </p>
                </button>
                <button
                  onClick={() => playPlaylist(pl)}
                  disabled={(pl.tracks || []).length === 0}
                  className="pixel-icon-btn h-9 w-9 shrink-0 pixel-btn-mint"
                  title="Play"
                >
                  <Play className="w-4 h-4" />
                </button>
                <button
                  onClick={() => removePlaylist(pl)}
                  className="pixel-icon-btn h-9 w-9 shrink-0"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              {openId === pl.id && (pl.tracks || []).length > 0 && (
                <div className="border-t-2 border-black/20 px-2 py-1 space-y-1">
                  {(pl.tracks || []).map((t, i) => (
                    <div key={i} className="flex items-center gap-2 py-1">
                      <div className="flex flex-col gap-0.5 shrink-0">
                        <button
                          onClick={() => reorderTrack(pl, i, i - 1)}
                          disabled={i === 0}
                          className="text-lav-muted hover:text-mint-accent disabled:opacity-30"
                          aria-label="Move up"
                        >
                          <ChevronUp className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => reorderTrack(pl, i, i + 1)}
                          disabled={i === (pl.tracks || []).length - 1}
                          className="text-lav-muted hover:text-mint-accent disabled:opacity-30"
                          aria-label="Move down"
                        >
                          <ChevronDown className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="w-7 h-7 pixel-inset shrink-0 overflow-hidden">
                        {t.cover_url && <img src={t.cover_url} alt="" className="w-full h-full object-cover" />}
                      </div>
                      <p className="pixel-body text-sm text-lav-text flex-1 truncate">{t.title}</p>
                      <button onClick={() => removeTrack(pl, i)} className="text-lav-muted hover:text-pink-accent">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}