import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1, Volume2, Volume1, VolumeX, ListMusic } from 'lucide-react';
import PixelSlider from './PixelSlider';
import { formatTime } from '@/lib/format';

export default function PlayerControls({ player }) {
  const {
    currentTrack, isPlaying, currentTime, duration, volume, isMuted,
    isShuffle, repeatMode, autoPlay, togglePlay, next, prev, seek, changeVolume, toggleMute,
    setIsShuffle, setRepeatMode, setAutoPlay,
  } = player;

  const cycleRepeat = () => {
    setRepeatMode(repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off');
  };

  const volIcon = isMuted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  return (
    <div className="pixel-panel p-3 sm:p-4">
      {/* Seek bar */}
      <div className="flex items-center gap-3">
        <span className="pixel-body text-base text-mint-accent w-10 text-right">{formatTime(currentTime)}</span>
        <PixelSlider value={currentTime} max={duration || 0} onChange={seek} color="#5fb88a" className="flex-1" />
        <span className="pixel-body text-base text-lav-muted w-10">{formatTime(duration)}</span>
      </div>

      {/* Transport */}
      <div className="mt-3 flex items-center justify-between gap-2">
        {/* left: shuffle + repeat */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsShuffle((s) => !s)}
            className={`pixel-icon-btn h-10 w-10 ${isShuffle ? 'is-active' : ''}`}
            aria-label="Shuffle"
          >
            <Shuffle className="w-4 h-4" />
          </button>
          <button
            onClick={cycleRepeat}
            className={`pixel-icon-btn h-10 w-10 ${repeatMode !== 'off' ? 'is-active' : ''}`}
            aria-label="Repeat"
          >
            {repeatMode === 'one' ? <Repeat1 className="w-4 h-4" /> : <Repeat className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setAutoPlay((a) => !a)}
            className={`pixel-icon-btn h-10 w-10 ${autoPlay ? 'is-active' : ''}`}
            aria-label="Auto play"
            title="Auto play — continue through the queue"
          >
            <ListMusic className="w-4 h-4" />
          </button>
        </div>

        {/* center: prev / play / next */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button onClick={prev} className="pixel-icon-btn h-12 w-12" aria-label="Previous">
            <SkipBack className="w-5 h-5" />
          </button>
          <button
            onClick={togglePlay}
            disabled={!currentTrack}
            className="pixel-icon-btn pixel-btn-accent h-16 w-16"
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-1" />}
          </button>
          <button onClick={next} className="pixel-icon-btn h-12 w-12" aria-label="Next">
            <SkipForward className="w-5 h-5" />
          </button>
        </div>

        {/* right: volume */}
        <div className="flex items-center gap-2 w-32 sm:w-44">
          <button onClick={toggleMute} className="pixel-icon-btn h-10 w-10 shrink-0" aria-label="Mute">
            {React.createElement(volIcon, { className: 'w-4 h-4' })}
          </button>
          <PixelSlider
            value={isMuted ? 0 : volume}
            max={1}
            onChange={changeVolume}
            color="#d67ba8"
            className="flex-1"
          />
        </div>
      </div>
    </div>
  );
}