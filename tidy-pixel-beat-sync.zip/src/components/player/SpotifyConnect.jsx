import React, { useState } from 'react';
import { beginSpotifyLogin, clearSpotifyTokens, redirectUri } from '@/lib/spotifyAuth';

export default function SpotifyConnect({ connected }) {
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState('');

  const uri = typeof window !== 'undefined' ? redirectUri() : '';

  const connect = async () => {
    setConnecting(true);
    setError('');
    try {
      await beginSpotifyLogin();
    } catch (e) {
      setError(e?.message || 'Failed to start');
      setConnecting(false);
    }
  };

  const disconnect = () => {
    clearSpotifyTokens();
    window.location.reload();
  };

  return (
    <div className="flex flex-col items-end gap-1">
      <button
        onClick={connected ? disconnect : connect}
        disabled={connecting}
        className={`pixel-btn px-3 py-2 text-[8px] sm:text-[10px] flex items-center gap-2 ${connected ? 'pixel-btn-accent' : 'pixel-btn-pink'}`}
      >
        <span className="w-2 h-2 bg-current" />
        {connecting ? 'LINKING...' : connected ? 'SPOTIFY ON' : 'CONNECT SPOTIFY'}
      </button>
      {error && <span className="pixel-body text-sm text-pink-accent">{error}</span>}
      {!connected && !error && (
        <span className="pixel-body text-[10px] text-lav-muted text-right max-w-[220px] leading-tight">
          Click to sign into your own Spotify. Premium = full songs; Free = 30s previews.
        </span>
      )}
    </div>
  );
}