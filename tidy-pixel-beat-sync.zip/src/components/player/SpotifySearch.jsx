import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, Play } from 'lucide-react';

export default function SpotifySearch({ onPlayTrack, spotifyConnected, playerReady }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState('');

  const fullPlayback = spotifyConnected && playerReady;

  const search = async (e) => {
    e?.preventDefault();
    const q = query.trim();
    if (!q) return;
    setSearching(true);
    setError('');
    setResults([]);
    try {
      const res = await base44.functions.invoke('spotifyLink', { query: q });
      const data = res?.data ?? res ?? {};
      if (!data.connected) {
        setError(data.message || 'Spotify not linked');
        return;
      }
      setResults(data.results || []);
    } catch (err) {
      setError(err?.response?.data?.message || err?.message || 'Search failed');
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="pixel-panel p-4">
      <form onSubmit={search} className="flex gap-2">
        <div className="flex-1 pixel-inset flex items-center gap-2 px-2">
          <Search className="w-4 h-4 text-lav-muted shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="SEARCH SPOTIFY..."
            className="flex-1 bg-transparent outline-none pixel-body text-lg text-lav-text placeholder:text-lav-muted py-1"
          />
        </div>
        <button type="submit" disabled={searching || !query.trim()} className="pixel-btn pixel-btn-accent px-3 py-2 text-[8px] sm:text-[10px]">
          {searching ? '...' : 'GO'}
        </button>
      </form>

      <div className="mt-2 flex items-center gap-2">
        <span className={`pixel-body text-xs ${fullPlayback ? 'text-mint-accent' : 'text-lav-muted'}`}>
          {fullPlayback ? 'FULL PLAYBACK READY' : spotifyConnected ? 'CONNECTING PLAYER...' : 'PREVIEW MODE — connect Spotify for full songs'}
        </span>
      </div>

      {error && <p className="pixel-body text-base text-pink-accent mt-2">{error}</p>}

      {results.length > 0 && (
        <div className="mt-3 pixel-inset max-h-72 overflow-y-auto pixel-scroll">
          {results.map((t, i) => {
            const canPlay = fullPlayback ? true : !!t.preview_url;
            return (
              <button
                key={`${t.spotify_uri}-${i}`}
                onClick={() => canPlay && onPlayTrack(t)}
                disabled={!canPlay}
                className={`w-full flex items-center gap-3 p-2 text-left border-b-2 border-[#5fb88a]/30 ${canPlay ? 'hover:bg-[#a7e9c5]' : 'opacity-40 cursor-not-allowed'}`}
              >
                <div className="w-10 h-10 pixel-inset shrink-0 overflow-hidden">
                  {t.cover_url ? (
                    <img src={t.cover_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-lav-muted">♪</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="pixel-body text-lg text-lav-text truncate leading-tight">{t.title}</p>
                  <p className="pixel-body text-sm text-mint-accent truncate leading-tight">{t.artist}</p>
                </div>
                <span className="pixel-body text-[10px] text-lav-muted shrink-0">
                  {fullPlayback ? 'FULL' : t.preview_url ? 'PREV' : 'N/A'}
                </span>
                {canPlay && <Play className="w-4 h-4 text-mint-accent shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}