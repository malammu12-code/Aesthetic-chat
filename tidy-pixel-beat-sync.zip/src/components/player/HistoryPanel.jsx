import React from 'react';
import { Play, History } from 'lucide-react';

export default function HistoryPanel({ history, onPlay }) {
  return (
    <div className="pixel-panel p-3 sm:p-4">
      <div className="flex items-center gap-2 mb-3 px-1">
        <History className="w-4 h-4 text-pink-accent" />
        <h3 className="pixel-font text-[10px] sm:text-xs text-pink-accent">RECENTLY PLAYED</h3>
        <span className="pixel-body text-base text-lav-muted ml-auto">{history.length}</span>
      </div>
      {history.length === 0 ? (
        <p className="pixel-body text-lg text-lav-muted text-center py-6">No history yet — play a track!</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {history.map((t, i) => (
            <button
              key={t.id || i}
              onClick={() => onPlay?.(t)}
              className="flex items-center gap-2 p-2 border-[3px] border-[#5fb88a] bg-[#e8faf0] hover:bg-[#ffc1de] text-left transition-colors"
            >
              <div className="w-9 h-9 shrink-0 border-2 border-[#5fb88a] overflow-hidden bg-[#a7e9c5]">
                {t.cover_url ? <img src={t.cover_url} alt="" className="w-full h-full object-cover" /> : null}
              </div>
              <div className="flex-1 min-w-0">
                <p className="pixel-body text-base leading-tight truncate">{t.title}</p>
                <p className="pixel-body text-sm leading-tight truncate text-lav-muted">{t.artist}</p>
              </div>
              <Play className="w-3 h-3 shrink-0 text-mint-accent" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}