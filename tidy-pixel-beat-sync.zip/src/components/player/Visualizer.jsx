import React from 'react';

export default function Visualizer({ isPlaying }) {
  const bars = Array.from({ length: 28 });
  return (
    <div className="flex items-end justify-center gap-[3px] h-10">
      {bars.map((_, i) => (
        <div
          key={i}
          className="w-[3px] h-full origin-bottom"
          style={{
            background: 'linear-gradient(to top, #ffc1de, #c9b3ff, #b3e0ff)',
            transform: isPlaying ? undefined : 'scaleY(0.12)',
            animation: isPlaying
              ? `pixel-pulse ${0.35 + (i % 4) * 0.18}s ${i * 0.045}s infinite ease-in-out`
              : 'none',
          }}
        />
      ))}
    </div>
  );
}