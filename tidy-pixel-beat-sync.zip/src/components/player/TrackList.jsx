import React from 'react';
import { Play, Pause, Trash2, ChevronUp, ChevronDown } from 'lucide-react';
import { formatTime } from '@/lib/format';

export default function TrackList({ tracks, currentIndex, onSelect, isPlaying, onReorder, onDelete }) {
  return (
    <div className="pixel-panel p-3 sm:p-4 h-full flex flex-col">
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="pixel-font text-[10px] sm:text-xs text-cyan-accent">QUEUE</h3>
        <span className="pixel-body text-lg text-lav-muted">{tracks.length} tracks</span>
      </div>
      <div className="flex-1 overflow-y-auto pixel-scroll space-y-1 pr-1">
        {tracks.map((t, i) => {
          const active = i === currentIndex;
          return (
            <div
              key={t.id || i}
              onClick={() => onSelect(i)}
              className={`w-full flex items-center gap-2 p-2 border-[3px] border-[#5fb88a] cursor-pointer transition-colors ${
                active ? 'bg-[#a7e9c5] text-[#3d7a5e]' : 'bg-[#e8faf0] text-lav-text hover:bg-[#a7e9c5]'
              }`}
            >
              {onReorder && (
                <div className="flex flex-col gap-0.5 shrink-0">
                  <button
                    onClick={(e) => { e.stopPropagation(); onReorder(i, i - 1); }}
                    disabled={i === 0}
                    className="pixel-icon-btn h-5 w-6 text-[10px] disabled:opacity-30"
                    aria-label="Move up"
                    title="Move up"
                  >
                    <ChevronUp className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); onReorder(i, i + 1); }}
                    disabled={i === tracks.length - 1}
                    className="pixel-icon-btn h-5 w-6 text-[10px] disabled:opacity-30"
                    aria-label="Move down"
                    title="Move down"
                  >
                    <ChevronDown className="w-3 h-3" />
                  </button>
                </div>
              )}
              <div className="h-10 w-10 shrink-0 border-2 border-[#5fb88a] overflow-hidden bg-[#a7e9c5]">
                {t.cover_url ? (
                  <img src={t.cover_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="pixel-body text-lg leading-tight truncate">{t.title}</p>
                <p className={`pixel-body text-base leading-tight truncate ${active ? 'text-[#3d7a5e]/80' : 'text-lav-muted'}`}>
                  {t.artist}
                </p>
              </div>
              <div className="shrink-0">
                {active && isPlaying ? (
                  <Pause className="w-4 h-4" />
                ) : active ? (
                  <Play className="w-4 h-4" />
                ) : (
                  <span className="pixel-body text-base">{t.duration ? formatTime(t.duration) : '--:--'}</span>
                )}
              </div>
              {onDelete && (
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(i); }}
                  className="pixel-icon-btn pixel-btn-pink h-8 w-8 shrink-0"
                  aria-label="Delete track"
                  title="Delete track"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}