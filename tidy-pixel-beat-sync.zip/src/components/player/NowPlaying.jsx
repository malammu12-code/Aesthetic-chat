import React from 'react';
import Visualizer from './Visualizer';

export default function NowPlaying({ track, isPlaying }) {
  return (
    <div className="pixel-panel p-4 sm:p-6">
      <div className="relative aspect-square w-full max-w-xs mx-auto pixel-inset overflow-hidden">
        {track?.cover_url ? (
          <img src={track.cover_url} alt={track.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center pixel-body text-3xl text-lav-muted">
            NO TRACK
          </div>
        )}
        {isPlaying && (
          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-[#3d7a5e]/85 to-transparent">
            <Visualizer isPlaying={isPlaying} />
          </div>
        )}
      </div>
      <div className="mt-4 text-center">
        <h2 className="pixel-font text-xs sm:text-sm text-lav-text truncate">{track?.title || '—'}</h2>
        <p className="pixel-body text-2xl text-mint-accent mt-2 truncate">{track?.artist || '—'}</p>
        {track?.album && <p className="pixel-body text-lg text-lav-muted truncate">{track.album}</p>}
      </div>
    </div>
  );
}