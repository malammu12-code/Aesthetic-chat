import React, { useEffect, useRef, useState, useCallback } from 'react';

const W = 680, H = 220;
const GROUND = 182;
const GRAVITY = 0.8;
const JUMP_V = -14;
const PX = 54, PW = 30, PH = 36;

function spawnObstacle(s) {
  const h = 26 + Math.floor(Math.random() * 32);
  s.obstacles.push({ x: W, y: GROUND - h, w: 22, h });
}

function draw(ctx, s) {
  ctx.clearRect(0, 0, W, H);
  // ground line
  ctx.fillStyle = '#3d7a5e';
  ctx.fillRect(0, GROUND, W, 3);
  ctx.fillStyle = '#7fae95';
  for (let x = 0; x < W; x += 22) ctx.fillRect(x, GROUND + 5, 8, 3);
  // player
  const py = GROUND - PH + s.player.y;
  ctx.fillStyle = '#3d7a5e';
  ctx.fillRect(PX, py, PW, PH);
  ctx.fillStyle = '#fff5fb';
  ctx.fillRect(PX + 19, py + 8, 7, 7);
  ctx.fillStyle = '#3d7a5e';
  ctx.fillRect(PX + 3, py + PH - 9, 11, 9);
  ctx.fillRect(PX + 17, py + PH - 9, 11, 9);
  // obstacles
  ctx.fillStyle = '#b8528a';
  for (const o of s.obstacles) ctx.fillRect(o.x, o.y, o.w, o.h);
  ctx.fillStyle = '#d67ba8';
  for (const o of s.obstacles) ctx.fillRect(o.x, o.y, o.w, 4);
  // score
  ctx.fillStyle = '#3d7a5e';
  ctx.font = '13px monospace';
  ctx.textAlign = 'right';
  ctx.fillText('SCORE ' + Math.floor(s.score), W - 10, 22);
  ctx.textAlign = 'left';
  if (s.over) {
    ctx.fillStyle = 'rgba(255,245,251,0.82)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#b8528a';
    ctx.font = '20px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('GAME OVER', W / 2, H / 2 - 8);
    ctx.font = '13px monospace';
    ctx.fillText('TAP / SPACE TO RESTART', W / 2, H / 2 + 18);
    ctx.textAlign = 'left';
  }
}

export default function RhythmGame({ audioEl, isPlaying, onGameOver, highScore }) {
  const canvasRef = useRef(null);
  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const freqRef = useRef(null);
  const sourceReady = useRef(false);
  const onGameOverRef = useRef(onGameOver);
  onGameOverRef.current = onGameOver;
  const stateRef = useRef({
    player: { y: 0, vy: 0, onGround: true },
    obstacles: [],
    speed: 3.2,
    score: 0,
    over: false,
    lastBeat: 0,
    lastSpawn: 0,
    energyAvg: 0,
    raf: 0,
  });
  const [over, setOver] = useState(false);
  const [score, setScore] = useState(0);

  const ensureAudio = useCallback(() => {
    if (!audioEl || sourceReady.current) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ac = new AC();
      const src = ac.createMediaElementSource(audioEl);
      const an = ac.createAnalyser();
      an.fftSize = 1024;
      src.connect(an);
      an.connect(ac.destination);
      audioCtxRef.current = ac;
      analyserRef.current = an;
      freqRef.current = new Uint8Array(an.frequencyBinCount);
      sourceReady.current = true;
    } catch (e) {
      sourceReady.current = true;
    }
  }, [audioEl]);

  const reset = useCallback(() => {
    const s = stateRef.current;
    s.player = { y: 0, vy: 0, onGround: true };
    s.obstacles = [];
    s.speed = 3.2;
    s.score = 0;
    s.over = false;
    s.lastSpawn = 0;
    setOver(false);
    setScore(0);
  }, []);

  const jump = useCallback(() => {
    ensureAudio();
    if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
    const s = stateRef.current;
    if (s.over) { reset(); return; }
    if (s.player.onGround) {
      s.player.vy = JUMP_V;
      s.player.onGround = false;
    }
  }, [ensureAudio, reset]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const s = stateRef.current;

    const onKey = (e) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') { e.preventDefault(); jump(); }
    };
    window.addEventListener('keydown', onKey);
    canvas.addEventListener('pointerdown', jump);

    let last = performance.now();
    const loop = (now) => {
      last = now;

      let beat = false;
      const an = analyserRef.current;
      if (an && isPlaying) {
        an.getByteFrequencyData(freqRef.current);
        let bass = 0;
        for (let i = 0; i < 8; i++) bass += freqRef.current[i];
        bass /= 8;
        s.energyAvg = s.energyAvg * 0.95 + bass * 0.05;
        if (bass > s.energyAvg * 1.35 && bass > 80 && now - s.lastBeat > 200) {
          s.lastBeat = now;
          beat = true;
        }
      }

      if (isPlaying && !s.over) {
        if (beat) { spawnObstacle(s); s.lastSpawn = now; }
        else if (now - s.lastSpawn > 850 && now - s.lastBeat > 500) { spawnObstacle(s); s.lastSpawn = now; }

        s.player.vy += GRAVITY;
        s.player.y += s.player.vy;
        if (s.player.y >= 0) { s.player.y = 0; s.player.vy = 0; s.player.onGround = true; }
        for (const o of s.obstacles) o.x -= s.speed;
        s.obstacles = s.obstacles.filter((o) => o.x > -30);
        s.score += 1;
        s.speed = Math.min(7.5, 3.2 + s.score / 1400);

        const pbox = { x: PX, y: GROUND - PH + s.player.y, w: PW, h: PH };
        for (const o of s.obstacles) {
          if (pbox.x < o.x + o.w && pbox.x + pbox.w > o.x && pbox.y < o.y + o.h && pbox.y + pbox.h > o.y) {
            s.over = true; const sc = Math.floor(s.score); setOver(true); setScore(sc); onGameOverRef.current?.(sc);
          }
        }
      }

      draw(ctx, s);
      s.raf = requestAnimationFrame(loop);
    };
    s.raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(s.raf);
      window.removeEventListener('keydown', onKey);
      canvas.removeEventListener('pointerdown', jump);
    };
  }, [isPlaying, jump]);

  return (
    <div className="pixel-panel p-3 sm:p-4">
      <div className="flex items-center justify-between mb-2 px-1">
        <h3 className="pixel-font text-[10px] sm:text-xs text-pink-accent">RHYTHM RUN</h3>
        <span className="pixel-body text-base text-lav-muted">
          {over ? `FINAL ${score}` : `SCORE ${Math.floor(stateRef.current.score)}`} · BEST {highScore || 0}
        </span>
      </div>
      <canvas
        ref={canvasRef}
        width={W}
        height={H}
        className="w-full block pixel-inset"
        style={{ imageRendering: 'pixelated', aspectRatio: `${W}/${H}` }}
      />
      <p className="pixel-body text-sm text-lav-muted mt-2 text-center">
        Tap the game or press SPACE to jump — obstacles drop on the beat.
      </p>
    </div>
  );
}