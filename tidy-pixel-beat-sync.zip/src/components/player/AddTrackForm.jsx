import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { getValidAccessToken } from '@/lib/spotifyAuth';
import { Plus, X, Loader2 } from 'lucide-react';

function queryFromUrl(url) {
  try {
    const path = new URL(url).pathname;
    const file = decodeURIComponent(path.split('/').pop() || '');
    const base = file.replace(/\.[^/.]+$/, '');
    return base.replace(/[_\-]+/g, ' ').replace(/\s+/g, ' ').trim();
  } catch {
    return '';
  }
}

function isSpotifyTrackUrl(url) {
  return /open\.spotify\.com\/track|spotify:track:/.test(url);
}

function isSpotifyPlaylistUrl(url) {
  return /open\.spotify\.com\/playlist|spotify:playlist:/.test(url);
}

export default function AddTrackForm({ onAdded, onPlay }) {
  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const mapSpotifyItem = (t) => ({
    title: t.title,
    artist: t.artist,
    album: t.album || '',
    cover_url: t.cover_url || '',
    audio_url: t.preview_url || '',
    spotify_uri: t.spotify_uri,
    duration: t.duration_ms ? Math.round(t.duration_ms / 1000) : 0,
    source: 'spotify',
  });

  const addSpotifyTrack = async (raw) => {
    const res = await base44.functions.invoke('spotifyLink', { mode: 'resolve', url: raw });
    const data = res?.data ?? res ?? {};
    const top = data.results?.[0];
    if (!top) throw new Error('Track not found on Spotify');
    return mapSpotifyItem(top);
  };

  const addSpotifyPlaylist = async (raw) => {
    const token = await getValidAccessToken();
    if (!token) throw new Error('Connect Spotify first to load playlists');
    const m = raw.match(/playlist[/:]([a-zA-Z0-9]+)/);
    const playlistId = m ? m[1] : raw;
    const r = await fetch(`https://api.spotify.com/v1/playlists/${playlistId}/tracks?limit=100`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!r.ok) throw new Error('Playlist not found or not accessible');
    const data = await r.json();
    const items = (data.items || []).map((it) => it.track).filter(Boolean);
    if (!items.length) throw new Error('Playlist is empty');
    return items.map((t) => mapSpotifyItem({
      title: t.name,
      artist: (t.artists || []).map((a) => a.name).join(', '),
      album: t.album?.name || '',
      cover_url: t.album?.images?.[0]?.url || '',
      duration_ms: t.duration_ms,
      spotify_uri: t.uri,
      preview_url: t.preview_url,
    }));
  };

  const addAudioTrack = async (raw) => {
    const query = queryFromUrl(raw);
    let meta = { title: query || 'Unknown Track', artist: 'Unknown Artist', cover_url: '' };
    if (query) {
      try {
        const res = await base44.functions.invoke('spotifyLink', { query });
        const data = res?.data ?? res ?? {};
        const top = data.results?.[0];
        if (top) meta = { title: top.title, artist: top.artist, cover_url: top.cover_url || '' };
      } catch (_) {}
    }
    return base44.entities.Track.create({
      title: meta.title,
      artist: meta.artist,
      audio_url: raw,
      cover_url: meta.cover_url,
      source: 'local',
    });
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!url.trim()) {
      setError('Paste a song URL');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const raw = url.trim();
      let added;
      if (isSpotifyPlaylistUrl(raw)) {
        added = await addSpotifyPlaylist(raw);
      } else if (isSpotifyTrackUrl(raw)) {
        added = await addSpotifyTrack(raw);
      } else {
        added = await addAudioTrack(raw);
      }
      const list = Array.isArray(added) ? added : [added];
      onAdded?.(list);
      onPlay?.();
      setUrl('');
      setOpen(false);
    } catch (err) {
      setError(err?.message || 'Failed to add track');
    } finally {
      setBusy(false);
    }
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="pixel-btn pixel-btn-mint px-3 py-2 text-[9px] sm:text-[10px] flex items-center gap-2"
      >
        <Plus className="w-3 h-3" /> ADD TRACK
      </button>
    );
  }

  return (
    <div className="pixel-panel p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="pixel-font text-[10px] text-mint-accent">ADD BY URL</h3>
        <button onClick={() => setOpen(false)} className="pixel-icon-btn h-8 w-8" aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>
      <p className="pixel-body text-sm text-lav-muted mb-2">
        Paste a Spotify song or playlist link, or a direct audio URL — we'll find the title, artist and cover.
      </p>
      <form onSubmit={submit} className="space-y-2">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Spotify song/playlist link, or audio URL"
          className="pixel-inset w-full px-3 py-2 pixel-body text-lg text-lav-text placeholder:text-lav-muted focus:outline-none"
        />
        {error && <p className="pixel-body text-sm text-pink-accent">{error}</p>}
        <button
          type="submit"
          disabled={busy}
          className="pixel-btn pixel-btn-accent px-4 py-2 text-[10px] w-full flex items-center justify-center gap-2"
        >
          {busy ? <><Loader2 className="w-3 h-3 animate-spin" /> FINDING...</> : 'ADD & PLAY'}
        </button>
      </form>
    </div>
  );
}