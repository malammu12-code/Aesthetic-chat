import React, { useRef, useState, useEffect, useCallback } from 'react';

export default function PixelSlider({ value, max, onChange, color = '#05ffa1', className = '' }) {
  const ref = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [dragPct, setDragPct] = useState(null);

  const basePct = max ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  const pct = dragging && dragPct != null ? dragPct : basePct;

  const update = useCallback(
    (clientX) => {
      if (!ref.current) return;
      const rect = ref.current.getBoundingClientRect();
      const w = rect.width || 1;
      const x = Math.max(0, Math.min(clientX - rect.left, w));
      setDragPct((x / w) * 100);
      onChange((x / w) * (max || 0));
    },
    [max, onChange]
  );

  useEffect(() => {
    if (!dragging) return;
    const move = (e) => update(e.clientX);
    const up = () => { setDragging(false); setDragPct(null); };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
  }, [dragging, update]);

  return (
    <div
      ref={ref}
      onPointerDown={(e) => {
        e.preventDefault();
        setDragging(true);
        setDragPct(null);
        update(e.clientX);
      }}
      className={`relative h-4 cursor-pointer pixel-inset flex items-center ${className}`}
    >
      <div className="absolute left-0 top-0 bottom-0" style={{ width: `${pct}%`, backgroundColor: color }} />
      <div
        className="absolute h-5 w-[6px] border-2 border-black"
        style={{ left: `calc(${pct}% - 3px)`, backgroundColor: color }}
      />
    </div>
  );
}