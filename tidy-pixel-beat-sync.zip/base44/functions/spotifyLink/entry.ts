import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';
import { secrets } from 'base44:runtime';

export default async function(req) {
  try {
    const clientId = secrets.get('SPOTIFY_CLIENT_ID');
    const clientSecret = secrets.get('SPOTIFY_CLIENT_SECRET');

    let payload = {};
    try { payload = await req.json(); } catch (_) {}
    const mode = payload?.mode;

    // --- Public OAuth operations (no app-user auth required) ---
    if (mode === 'config') {
      return Response.json({ client_id: clientId || null });
    }

    if (mode === 'exchange') {
      if (!clientId || !clientSecret) return Response.json({ error: 'Spotify not configured' }, { status: 500 });
      const body = new URLSearchParams({
        grant_type: 'authorization_code',
        code: payload.code,
        redirect_uri: payload.redirect_uri,
        client_id: clientId,
        client_secret: clientSecret,
      });
      const r = await fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      const data = await r.json();
      if (!r.ok) return Response.json({ error: data.error || 'exchange_failed' }, { status: 400 });
      return Response.json(data);
    }

    if (mode === 'refresh') {
      if (!clientId || !clientSecret) return Response.json({ error: 'Spotify not configured' }, { status: 500 });
      const body = new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: payload.refresh_token,
        client_id: clientId,
        client_secret: clientSecret,
      });
      const r = await fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });
      const data = await r.json();
      if (!r.ok) return Response.json({ error: data.error || 'refresh_failed' }, { status: 400 });
      return Response.json(data);
    }

    // --- Status + search: require app user auth ---
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    if (!clientId || !clientSecret) {
      return Response.json({ connected: false, message: 'Spotify credentials not configured.' });
    }

    const query = typeof payload?.query === 'string' ? payload.query.trim() : '';

    const tokenBody = new URLSearchParams({ grant_type: 'client_credentials' });
    const auth = btoa(`${clientId}:${clientSecret}`);
    const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
      body: tokenBody,
    });
    if (!tokenRes.ok) return Response.json({ connected: false, message: 'Spotify rejected credentials.' });
    const tokenData = await tokenRes.json();

    // Resolve a single track by Spotify URL or id
    if (mode === 'resolve') {
      const raw = (payload.url || payload.track_id || '').toString();
      const m = raw.match(/track[/:]([a-zA-Z0-9]+)/);
      const trackId = m ? m[1] : raw;
      if (!trackId) return Response.json({ connected: true, message: 'No track id.' });
      const r = await fetch(`https://api.spotify.com/v1/tracks/${trackId}`, {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      if (!r.ok) return Response.json({ connected: true, message: 'Track not found.' });
      const t = await r.json();
      const item = {
        title: t.name,
        artist: (t.artists || []).map((a) => a.name).join(', '),
        album: t.album?.name || '',
        cover_url: t.album?.images?.[0]?.url || '',
        duration_ms: t.duration_ms,
        spotify_uri: t.uri,
        preview_url: t.preview_url,
      };
      return Response.json({ connected: true, results: [item] });
    }

    if (!query) return Response.json({ connected: true });

    const searchRes = await fetch(
      `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=10`,
      { headers: { Authorization: `Bearer ${tokenData.access_token}` } }
    );
    if (!searchRes.ok) return Response.json({ connected: true, message: 'Search failed.' });
    const searchData = await searchRes.json();
    const items = (searchData.tracks?.items || []).map((t) => ({
      title: t.name,
      artist: (t.artists || []).map((a) => a.name).join(', '),
      album: t.album?.name || '',
      cover_url: t.album?.images?.[0]?.url || '',
      duration_ms: t.duration_ms,
      spotify_uri: t.uri,
      preview_url: t.preview_url,
    }));
    return Response.json({ connected: true, results: items });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}