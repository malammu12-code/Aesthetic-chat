# 🎮 Pixel Player

A retro, pixel-art music player that syncs with Spotify. Stream full tracks with a
Premium account, play local audio URLs, build custom playlists, and jump obstacles in a
beat-synced mini-game — all wrapped in a pastel green-and-pink 8-bit aesthetic.

> **Live app:** https://tidy-pixel-beat-sync.base44.app

---

## ✨ Features

- **Spotify integration** — OAuth (Premium = full songs, Free = 30s previews), search, and
  playback through the Spotify Web Playback SDK.
- **Local audio** — paste any direct audio URL; metadata is auto-resolved via Spotify search.
- **Queue + playlists** — reorder (up/down), per-track delete, create named playlists, add the
  currently playing track, and play a whole playlist.
- **Recently Played** — every play is logged and shown in a history grid; replay from there.
- **Rhythm Run mini-game** — a Canvas endless-runner where obstacles spawn on the beat of the
  audio (Web Audio API analyser). High scores persist per user.
- **State persistence** — your queue, queue position, listening history, and high scores are
  saved to your account and restored on reload.
- **Pixel aesthetic** — `Press Start 2P` / `VT323` fonts, chunky borders, and a pastel
  green-and-pink theme.

---

## 🛠 Tech Stack

- **Frontend:** React 18 + Vite, Tailwind CSS, shadcn/ui, lucide-react icons
- **Backend:** Base44 BaaS (auth, database, integrations, hosting)
- **Spotify:** Web Playback SDK (client streaming) + Web API (search/resolve) via a backend function
- **Persistence:** Base44 entities (`Track`, `Playlist`, `UserQueue`, `ListeningHistory`, `GameScore`)
- **Audio analysis:** Web Audio API (`AnalyserNode`) for beat detection in the mini-game

---

## 📁 Project Structure

```
├─ index.html                      # Fonts (Press Start 2P, VT323), meta, root mount
├─ src/
│  ├─ App.jsx                      # Router + auth provider + protected routes
│  ├─ index.css                    # Tailwind tokens + pastel pixel theme (pixel-panel, pixel-btn…)
│  ├─ pages/
│  │  ├─ Home.jsx                  # Main screen: wires players, queue, history, game, persistence
│  │  ├─ Login.jsx                 # Email + Google + Spotify pre-connect
│  │  ├─ Register.jsx / ForgotPassword.jsx / ResetPassword.jsx
│  ├─ components/
│  │  ├─ player/
│  │  │  ├─ NowPlaying.jsx         # Album art + equalizer overlay + track metadata
│  │  │  ├─ PlayerControls.jsx      # Seek, transport (play/pause/next/prev), shuffle/repeat, volume
│  │  │  ├─ PixelSlider.jsx         # Custom pointer-drag slider (seek + volume)
│  │  │  ├─ TrackList.jsx           # Queue with reorder + per-track delete
│  │  │  ├─ PlaylistPanel.jsx       # Create/list playlists, add current track, reorder, delete
│  │  │  ├─ SpotifySearch.jsx       # Search Spotify, play results
│  │  │  ├─ AddTrackForm.jsx        # Paste a Spotify song/playlist link or audio URL
│  │  │  ├─ SpotifyConnect.jsx      # Connect/disconnect Spotify
│  │  │  ├─ HistoryPanel.jsx        # Recently Played grid
│  │  │  ├─ RhythmGame.jsx          # Canvas beat-synced runner mini-game
│  │  │  └─ Visualizer.jsx          # Animated EQ bars
│  │  ├─ AuthLayout.jsx, GoogleIcon.jsx, ProtectedRoute.jsx, ScrollToTop.jsx
│  ├─ lib/
│  │  ├─ usePlayer.js              # Local <audio> playback hook (queue, shuffle, repeat, auto-advance)
│  │  ├─ useSpotifyPlayer.js       # Spotify Web Playback SDK hook (streaming + state)
│  │  ├─ spotifyAuth.js            # OAuth token storage/refresh + redirect handling
│  │  ├─ format.js                  # Time formatting helpers
│  │  └─ AuthContext.jsx, query-client.js, utils.js, PageNotFound.jsx
├─ base44/
│  ├─ entities/                    # JSON schemas (Track, Playlist, UserQueue, ListeningHistory, GameScore)
│  └─ functions/spotifyLink/entry.ts  # Spotify OAuth exchange + search/resolve proxy
```

---

## 🗄 Data Model (Base44 Entities)

| Entity            | Purpose                                              | Key fields                                   |
|-------------------|------------------------------------------------------|----------------------------------------------|
| `Track`           | Library of local/added audio tracks                 | title, artist, audio_url, cover_url, source  |
| `Playlist`        | User-created playlists                               | name, description, tracks[]                  |
| `UserQueue`       | Persisted queue (one per user)                       | tracks[], current_index                       |
| `ListeningHistory`| Recently Played log                                  | title, artist, cover_url, spotify_uri, source |
| `GameScore`       | Rhythm Run high scores                               | score, track_title                            |

Built-in `User` entity handles accounts/roles (admin/user).

---

## 🔌 Spotify Integration

A single backend function, `base44/functions/spotifyLink/entry.ts`, handles:

1. **OAuth config retrieval** — returns the client ID + redirect URI to the client.
2. **Authorization-code exchange** — swaps the Spotify callback code for access/refresh tokens.
3. **Token refresh** — refreshes expired access tokens server-side using the client secret.
4. **Search** — proxies `GET /v1/search` for track results.
5. **Resolve** — fetches full metadata for a track/playlist URL.

Client-side, `spotifyAuth.js` stores tokens in `localStorage` and `useSpotifyPlayer.js`
runs the **Spotify Web Playback SDK** for real-time streaming. Secrets
`SPOTIFY_CLIENT_ID` and `SPOTIFY_CLIENT_SECRET` are kept server-side via Base44 app secrets.

---

## 🎮 How the Mini-Game Works

`RhythmGame.jsx` taps the playing `<audio>` element through a Web Audio `AnalyserNode`,
reads the low-frequency (bass) band each frame, and spawns an obstacle whenever a beat
exceeds the rolling energy average. The player jumps with Space / tap; collisions end the
run and the score is saved to the `GameScore` entity.

---

## 🔐 Authentication

Boilerplate auth pages (`Login`, `Register`, `ForgotPassword`, `ResetPassword`) support
email/password, Google OAuth, and OTP verification. Authenticated routes are wrapped in
`ProtectedRoute`. The Login page also offers a Spotify pre-connect so streaming is ready
on first entry.

---

## 🚀 Getting Started

1. The app runs on the Base44 platform — open it in the builder to preview/publish.
2. Set the Spotify secrets (already configured here):
   - `SPOTIFY_CLIENT_ID`
   - `SPOTIFY_CLIENT_SECRET`
3. Register a Spotify app with a redirect URI of
   `https://tidy-pixel-beat-sync.base44.app` (handled by `spotifyAuth.js`).
4. Log in, click **Connect Spotify**, search a song, and hit play.

---

## 🎨 Theme

The pastel green-and-pink pixel look lives in `src/index.css`:

- `.pixel-panel` / `.pixel-inset` — chunky green-bordered surfaces
- `.pixel-btn` / `.pixel-btn-pink` / `.pixel-btn-mint` — retro buttons with hard shadows
- `.pixel-icon-btn` — icon buttons (active state flips to pink)
- `.pixel-font` (`Press Start 2P`) / `.pixel-body` (`VT323`) — typography
- Pink-tinted background with a green grid

---

## 📜 License

Personal project. Spotify playback requires a Spotify account; content rights belong to
their respective owners.