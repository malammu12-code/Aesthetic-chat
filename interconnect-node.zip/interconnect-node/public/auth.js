const form = document.getElementById('auth-form');
const email = document.getElementById('email');
const password = document.getElementById('password');
const confirm = document.getElementById('confirm');
const displayName = document.getElementById('displayName');
const title = document.getElementById('auth-title');
const btn = document.getElementById('auth-btn');
const toggleBtn = document.getElementById('toggle-btn');
const toggleLabel = document.getElementById('toggle-label');
const errorEl = document.getElementById('error');

let mode = 'login';

async function checkSession() {
  const res = await fetch('/api/me');
  if (res.ok && (await res.json())) location.href = 'app.html';
}
checkSession();

toggleBtn.addEventListener('click', () => {
  mode = mode === 'login' ? 'signup' : 'login';
  title.textContent = mode === 'login' ? 'Hello!' : 'Sign Up';
  btn.textContent = mode === 'login' ? 'Login' : 'Sign Up';
  toggleLabel.textContent = mode === 'login' ? "Don't have an account?" : 'Already have an account?';
  toggleBtn.textContent = mode === 'login' ? 'Sign Up' : 'Back to Login';
  confirm.classList.toggle('hidden', mode === 'login');
  displayName.classList.toggle('hidden', mode === 'login');
  errorEl.textContent = '';
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.textContent = '';

  if (mode === 'signup' && password.value !== confirm.value) {
    errorEl.textContent = 'Passwords do not match.';
    return;
  }

  const payload = { email: email.value, password: password.value };
  if (mode === 'signup') payload.displayName = displayName.value;

  const res = await fetch(`/api/${mode}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    errorEl.textContent = data.error || 'Something went wrong.';
    return;
  }

  location.href = 'app.html';
});
