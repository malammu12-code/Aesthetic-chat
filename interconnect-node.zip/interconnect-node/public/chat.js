const params = new URLSearchParams(location.search);
const peerId = parseInt(params.get('user'), 10);
const peerName = document.getElementById('peer-name');
const messagesEl = document.getElementById('messages');
const form = document.getElementById('composer');
const input = document.getElementById('message-input');
const imageInput = document.getElementById('image-input');
const cameraBtn = document.getElementById('camera-btn');
const typingEl = document.getElementById('typing');
let me = null;
let socket = null;

if (!peerId) location.href = 'app.html';

async function init() {
  const res = await fetch('/api/me');
  if (!res.ok) return location.href = 'index.html';
  me = await res.json();

  const peerRes = await fetch('/api/users');
  const users = peerRes.ok ? await peerRes.json() : [];
  const peer = users.find(u => u.id === peerId);
  if (peer) peerName.textContent = peer.display_name || 'Chat';

  const historyRes = await fetch(`/api/messages/${peerId}`);
  if (historyRes.ok) {
    const messages = await historyRes.json();
    messages.forEach(m => renderMessage(m));
  }

  socket = io();
  socket.on('message', m => renderMessage(m));
  socket.on('typing', () => {
    typingEl.textContent = 'typing...';
    setTimeout(() => typingEl.textContent = '', 1200);
  });

  input.addEventListener('input', () => socket.emit('typing', { receiverId: peerId }));
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  sendMessage({ body: text });
  input.value = '';
});

cameraBtn.addEventListener('click', () => imageInput.click());
imageInput.addEventListener('change', async () => {
  const file = imageInput.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('image', file);
  const res = await fetch('/api/upload', { method: 'POST', body: fd });
  if (!res.ok) return alert('Upload failed');
  const { url } = await res.json();
  sendMessage({ imageUrl: url });
  imageInput.value = '';
});

function sendMessage({ body, imageUrl }) {
  socket.emit('message', { receiverId: peerId, body, imageUrl });
}

function renderMessage(m) {
  const isMe = m.sender_id === me.id;
  const div = document.createElement('div');
  div.className = `bubble ${isMe ? 'outgoing' : 'incoming'}`;
  const time = new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  div.innerHTML = `
    ${m.body ? escape(m.body) : ''}
    ${m.image_url ? `<img src="${m.image_url}" alt="shared image" />` : ''}
    <time>${time}</time>
  `;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function escape(text) { const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }

init();
