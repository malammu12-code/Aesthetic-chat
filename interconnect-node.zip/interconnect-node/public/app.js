const chatList = document.getElementById('chat-list');
const friendList = document.getElementById('friend-list');
const discoverList = document.getElementById('discover-list');
const errorEl = document.getElementById('error');
const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.tab-panel');
let me = null;

function setError(msg) { errorEl.textContent = msg; }

tabs.forEach(tab => tab.addEventListener('click', () => {
  tabs.forEach(t => t.classList.remove('active'));
  panels.forEach(p => p.classList.remove('active'));
  tab.classList.add('active');
  document.getElementById(tab.dataset.tab).classList.add('active');
}));

async function loadMe() {
  const res = await fetch('/api/me');
  if (!res.ok) return location.href = 'index.html';
  me = await res.json();
  loadAll();
}

async function loadAll() {
  loadFriends();
  loadDiscover();
}

async function loadFriends() {
  const res = await fetch('/api/friends');
  if (!res.ok) return setError('Failed to load friends');
  const friends = await res.json();
  friendList.innerHTML = '';
  chatList.innerHTML = '';

  const accepted = friends.filter(f => f.status === 'accepted');
  accepted.forEach(f => {
    chatList.appendChild(renderItem(f, 'chat'));
    friendList.appendChild(renderItem(f, 'friend'));
  });

  const pending = friends.filter(f => f.status === 'pending');
  pending.forEach(f => {
    const isIncoming = f.requester_id !== me.id;
    const el = document.createElement('div');
    el.className = 'list-item';
    el.innerHTML = `
      <div class="avatar">${initial(f.display_name)}</div>
      <div class="item-name">${escape(f.display_name)}</div>
      <div class="item-meta">${isIncoming ? 'Incoming request' : 'Pending'}</div>
      ${isIncoming ? `
        <button class="action-btn accept" data-id="${f.id}">Accept</button>
        <button class="action-btn decline" data-id="${f.id}">Decline</button>
      ` : ''}
    `;
    friendList.appendChild(el);
  });

  if (!accepted.length) chatList.innerHTML = '<p class="empty">No chats yet. Add friends in Discover.</p>';
  if (!friends.length) friendList.innerHTML = '<p class="empty">No friends yet.</p>';

  friendList.querySelectorAll('.accept').forEach(btn => btn.addEventListener('click', () => respond(btn.dataset.id, 'accept')));
  friendList.querySelectorAll('.decline').forEach(btn => btn.addEventListener('click', () => respond(btn.dataset.id, 'decline')));
}

async function loadDiscover() {
  const res = await fetch('/api/users');
  if (!res.ok) return setError('Failed to load users');
  const users = await res.json();
  const friendsRes = await fetch('/api/friends');
  const friends = friendsRes.ok ? await friendsRes.json() : [];
  const friendIds = new Set(friends.map(f => f.id));
  discoverList.innerHTML = '';

  users.filter(u => !friendIds.has(u.id)).forEach(u => {
    const el = document.createElement('div');
    el.className = 'list-item';
    el.innerHTML = `
      <div class="avatar">${initial(u.display_name)}</div>
      <div class="item-name">${escape(u.display_name)}</div>
      <button class="action-btn accept" data-id="${u.id}">Add</button>
    `;
    discoverList.appendChild(el);
  });

  discoverList.querySelectorAll('.accept').forEach(btn => btn.addEventListener('click', () => addFriend(btn.dataset.id)));
  if (!users.length) discoverList.innerHTML = '<p class="empty">No users to discover.</p>';
}

function renderItem(u, type) {
  const el = document.createElement('div');
  el.className = 'list-item';
  el.innerHTML = `
    <div class="avatar">${initial(u.display_name)}</div>
    <div class="item-name">${escape(u.display_name)}</div>
    ${type === 'chat' ? '<div class="item-meta">Tap to chat</div>' : ''}
  `;
  el.addEventListener('click', () => location.href = `chat.html?user=${u.id}`);
  return el;
}

async function addFriend(userId) {
  const res = await fetch('/api/friends/request', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: parseInt(userId, 10) })
  });
  if (!res.ok) { setError((await res.json()).error || 'Failed'); return; }
  loadAll();
}

async function respond(userId, action) {
  const res = await fetch('/api/friends/respond', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: parseInt(userId, 10), action })
  });
  if (!res.ok) { setError((await res.json()).error || 'Failed'); return; }
  loadAll();
}

document.getElementById('logout').addEventListener('click', async () => {
  await fetch('/api/logout', { method: 'POST' });
  location.href = 'index.html';
});

function initial(name) { return (name || '?').trim().charAt(0).toUpperCase(); }
function escape(text) { const div = document.createElement('div'); div.textContent = text; return div.innerHTML; }

loadMe();
