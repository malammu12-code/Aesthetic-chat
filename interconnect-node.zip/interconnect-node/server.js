const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcryptjs');
const path = require('path');
const Database = require('better-sqlite3');
const multer = require('multer');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'app.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    display_name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS friendships (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    requester_id INTEGER NOT NULL REFERENCES users(id),
    addressee_id INTEGER NOT NULL REFERENCES users(id),
    status TEXT NOT NULL CHECK(status IN ('pending','accepted','declined')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(requester_id, addressee_id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL REFERENCES users(id),
    receiver_id INTEGER NOT NULL REFERENCES users(id),
    body TEXT,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

const sessionMiddleware = session({
  store: new SQLiteStore({ dir: DATA_DIR, db: 'sessions.db' }),
  secret: process.env.SESSION_SECRET || 'change-me-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000, httpOnly: true }
});
app.use(sessionMiddleware);
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOADS_DIR));

io.use((socket, next) => sessionMiddleware(socket.request, {}, next));

function requireAuth(req, res, next) {
  if (req.session.userId) return next();
  return res.status(401).json({ error: 'Not authenticated' });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

app.get('/api/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id, email, display_name FROM users WHERE id = ?').get(req.session.userId);
  res.json(user || null);
});

app.post('/api/signup', async (req, res) => {
  const { email, password, displayName } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  try {
    const hash = await bcrypt.hash(password, 10);
    const info = db.prepare('INSERT INTO users (email, password_hash, display_name) VALUES (?, ?, ?)').run(email, hash, displayName || email);
    req.session.userId = info.lastInsertRowid;
    res.json({ id: info.lastInsertRowid, email, displayName: displayName || email });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Email already exists' });
    console.error(err);
    res.status(500).json({ error: 'Signup failed' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  req.session.userId = user.id;
  res.json({ id: user.id, email: user.email, displayName: user.display_name });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

app.get('/api/users', requireAuth, (req, res) => {
  const users = db.prepare('SELECT id, email, display_name FROM users WHERE id != ?').all(req.session.userId);
  res.json(users);
});

app.get('/api/friends', requireAuth, (req, res) => {
  const friends = db.prepare(`
    SELECT u.id, u.email, u.display_name, f.status, f.requester_id
    FROM friendships f
    JOIN users u ON (u.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END)
    WHERE f.requester_id = ? OR f.addressee_id = ?
  `).all(req.session.userId, req.session.userId, req.session.userId);
  res.json(friends);
});

app.post('/api/friends/request', requireAuth, (req, res) => {
  const { userId } = req.body;
  if (!userId || userId === req.session.userId) return res.status(400).json({ error: 'Invalid user' });
  try {
    db.prepare('INSERT INTO friendships (requester_id, addressee_id, status) VALUES (?, ?, ?)').run(req.session.userId, userId, 'pending');
    res.json({ ok: true });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Friend request already exists' });
    throw err;
  }
});

app.post('/api/friends/respond', requireAuth, (req, res) => {
  const { userId, action } = req.body;
  const status = action === 'accept' ? 'accepted' : 'declined';
  const result = db.prepare(`
    UPDATE friendships SET status = ?, updated_at = CURRENT_TIMESTAMP
    WHERE addressee_id = ? AND requester_id = ?
  `).run(status, req.session.userId, userId);
  if (result.changes === 0) return res.status(404).json({ error: 'Request not found' });
  res.json({ ok: true, status });
});

app.get('/api/messages/:userId', requireAuth, (req, res) => {
  const other = parseInt(req.params.userId, 10);
  const messages = db.prepare(`
    SELECT m.*, s.display_name AS sender_name
    FROM messages m
    JOIN users s ON s.id = m.sender_id
    WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
    ORDER BY m.created_at ASC
  `).all(req.session.userId, other, other, req.session.userId);
  res.json(messages);
});

app.post('/api/upload', requireAuth, upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image' });
  res.json({ url: '/uploads/' + req.file.filename });
});

io.on('connection', (socket) => {
  const userId = socket.request.session?.userId;
  if (!userId) return socket.disconnect();
  socket.join(`user:${userId}`);

  socket.on('message', ({ receiverId, body, imageUrl }) => {
    const msg = db.prepare('INSERT INTO messages (sender_id, receiver_id, body, image_url) VALUES (?, ?, ?, ?)').run(userId, receiverId, body || null, imageUrl || null);
    const inserted = db.prepare('SELECT m.*, s.display_name AS sender_name FROM messages m JOIN users s ON s.id = m.sender_id WHERE m.id = ?').get(msg.lastInsertRowid);
    io.to(`user:${userId}`).to(`user:${receiverId}`).emit('message', inserted);
  });

  socket.on('typing', ({ receiverId }) => {
    socket.to(`user:${receiverId}`).emit('typing', { senderId: userId });
  });

  socket.on('disconnect', () => {});
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

server.listen(PORT, () => {
  console.log(`InterConnect running on http://localhost:${PORT}`);
});
