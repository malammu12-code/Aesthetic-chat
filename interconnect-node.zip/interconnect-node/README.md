# InterConnect Chat

A simple pastel chat app built with plain HTML, CSS, JavaScript, Node.js, Express, Socket.IO, and SQLite.

## Features

- Email + password login and sign up
- Friend requests, accept/decline
- Real-time one-to-one messaging with Socket.IO
- Send photos via Multer uploads
- Pastel gradient UI matching the original design references

## Project structure

```
interconnect-node/
├── server.js          # Express + Socket.IO backend
├── package.json       # Dependencies
├── README.md          # This file
├── public/            # Frontend HTML/CSS/JS
│   ├── index.html     # Login / sign up
│   ├── app.html       # Chats, Friends, Discover
│   ├── chat.html      # Direct messaging
│   ├── styles.css     # Pastel gradient UI
│   ├── auth.js
│   ├── app.js
│   └── chat.js
├── data/              # SQLite database (created at runtime)
└── uploads/           # Uploaded images (created at runtime)
```

## Install and run

```bash
npm install
npm start
```

Then open `http://localhost:3000` in your browser.

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `PORT` | `3000` | HTTP server port |
| `SESSION_SECRET` | `change-me-in-production` | Cookie session secret |

Set a strong `SESSION_SECRET` in production.

## API overview

- `POST /api/signup` - create account
- `POST /api/login` - sign in
- `POST /api/logout` - sign out
- `GET /api/me` - current user
- `GET /api/users` - list all users
- `GET /api/friends` - list friends and pending requests
- `POST /api/friends/request` - send friend request
- `POST /api/friends/respond` - accept/decline request
- `GET /api/messages/:userId` - message history with another user
- `POST /api/upload` - upload an image

Socket.IO events:

- `message` - send a real-time message `{ receiverId, body, imageUrl }`
- `typing` - typing indicator `{ receiverId }`
- `message` (incoming) - receive a new message
- `typing` (incoming) - peer is typing

## Notes

- This is a starter/self-hosted version. For production, use a stronger session secret, HTTPS, and a production database.
- Uploaded files are stored on disk in `uploads/` and served statically.
- The app uses SQLite for users, friendships, and messages.
